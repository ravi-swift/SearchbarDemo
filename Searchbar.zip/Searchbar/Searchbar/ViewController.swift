//
//  ViewController.swift
//  Searchbar
//
//  Created by Rp on 27/10/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,UISearchBarDelegate,UITextFieldDelegate {

    
    
    @IBOutlet var tbl : UITableView!
    
    let array1 = NSArray.init(objects: "Ravi","Search","Apple","Dharmesh","Dipak","Kalpesh","Rp","Hardik","Override","Super","Viewdid","Section","Loaddid","Table")

    var arrSearch = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        arrSearch = NSMutableArray.init(array: array1)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSearch.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let lbl = cell.viewWithTag(1001) as! UILabel
        lbl.text = arrSearch.object(at: indexPath.row) as! String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
   
    
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if text == "\n"
        {
            searchBar.resignFirstResponder()
            return true
        }
        else{
            
            var searchStr : NSString = ""
            if ((searchBar.text as! NSString).length == 0 && text != nil)
            {
                searchStr = text as NSString
            }
            else{
                searchStr = (searchBar.text! as NSString).appending(text) as NSString
            }
            
            arrSearch.removeAllObjects()
            
            if ((searchBar.text! as NSString).length > 0 && text == "")
            {
                searchStr = (searchBar.text as! NSString).substring(to: (searchBar.text as! NSString).length-1) as NSString
                
            }
            
            let predicate = NSPredicate.init(format: "SELF contains[cd] %@", searchStr)
            let filtereArray = array1.filtered(using: predicate)
            
            if filtereArray.count > 0{
                
               self.arrSearch.addObjects(from: filtereArray)
                self.tbl.isHidden = false
            }
            
            if text != ""
            {
                if arrSearch.count == 0
                {
                    arrSearch.removeAllObjects()
                    self.tbl.isHidden = true
                }
                
            }
            else{
                
                if searchStr == ""
                {
                    arrSearch.removeAllObjects()
                    self.tbl.isHidden = true
                }
            }
            
            tbl.reloadData()
            
        }
        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

